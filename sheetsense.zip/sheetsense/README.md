# SheetSense

AI-assisted spreadsheet analysis. Upload a CSV or Excel file and get a profile of every column, flagged data-quality problems, and plain-language insights. Ask follow-up questions about the data in natural language.

![status](https://img.shields.io/badge/stack-React%20%7C%20Node%20%7C%20MongoDB-2447d6)
![license](https://img.shields.io/badge/license-MIT-lightgrey)

<!-- Add a screenshot after you run it:  ![SheetSense screenshot](docs/screenshot.png) -->

## Features

- **Upload CSV, XLS or XLSX** (up to 10 MB / 50,000 rows by default, configurable)
- **Automatic column profiling**: type detection, missing values, unique counts, min/median/mean/max, standard deviation, IQR-based outlier detection, and a mini histogram per numeric column
- **Correlation detection** between numeric columns (Pearson r)
- **Insights**: written by an LLM when an API key is set, or by a rule-based statistical engine when it isn't, so the app always works
- **Ask questions** about a dataset in plain English (needs an API key)
- **Browse rows** with server-side pagination
- **Data management**: list, reopen and delete datasets

## Tech stack

| Layer | Tech |
| --- | --- |
| Frontend | React 18, Vite |
| Backend | Node.js, Express, Multer, SheetJS (`xlsx`) |
| Database | MongoDB with Mongoose |
| AI | Anthropic Messages API (optional) |
| Security | Helmet, CORS allow-list, rate limiting, upload type and size limits |

## Architecture

```
React (Vite)  --REST-->  Express API  --Mongoose-->  MongoDB
                            |                          |- datasets  (profile + insights)
                            |                          '- rows      (one doc per row)
                            '--> services/parser   file -> rows
                            '--> services/stats    rows -> column profiles, correlations
                            '--> services/ai       profile -> insights / answers
```

Design decisions worth knowing about:

- **Rows are stored in their own collection**, not embedded in the dataset document, so large sheets can't hit MongoDB's 16 MB document limit and pagination stays cheap. An index on `{ datasetId, index }` backs the paging query.
- **The AI never receives the whole sheet.** It gets a compact statistical profile plus a small sample of rows. This keeps cost and latency low and limits how much of a user's data leaves the server.
- **Statistics are computed locally**, then the model explains them. Numbers in the insights come from code, not from the model's arithmetic.
- **Graceful degradation.** No key, or a failed AI call, falls back to rule-based insights.
- **Failed imports clean up after themselves**, so no half-loaded datasets remain.

## Getting started

Requirements: Node 20+, and MongoDB (local or Atlas). Docker is the quickest way to get MongoDB.

```bash
git clone https://github.com/<your-username>/sheetsense.git
cd sheetsense

# 1. Database
docker compose up -d            # or point MONGODB_URI at your own instance

# 2. Install
npm run install:all

# 3. Configure
cp server/.env.example server/.env
# optional: add ANTHROPIC_API_KEY to server/.env for AI insights and Q&A

# 4. Run API (http://localhost:5000) and web app (http://localhost:5173)
npm run dev
```

Then upload `sample-data/sales.csv`. It contains a planted outlier in `units` and about 28% missing values in `customer_rating`, so the insights have something to find.

## Configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `5000` | API port |
| `MONGODB_URI` | `mongodb://127.0.0.1:27017/sheetsense` | Database connection |
| `CLIENT_ORIGIN` | `http://localhost:5173` | Allowed CORS origin |
| `ANTHROPIC_API_KEY` | empty | Enables AI insights and Q&A |
| `ANTHROPIC_MODEL` | `claude-sonnet-4-6` | Model used for AI calls |
| `MAX_UPLOAD_MB` | `10` | Upload size limit |
| `MAX_ROWS` | `50000` | Row limit per sheet |

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Runs API and web app together |
| `npm test` | Runs server unit tests (Node's built-in test runner) |
| `npm run build` | Builds the client for production |

API details are in [docs/API.md](docs/API.md).

## Project structure

```
sheetsense/
  client/                 React app
    src/components/       UploadZone, DatasetList, ColumnProfiles, InsightsPanel, DataTable
    src/api.js            REST client
  server/
    src/config/           env + database connection
    src/models/           Dataset, Row
    src/routes/           /api/datasets endpoints
    src/services/         parser, stats, ai
    src/middleware/       error handling
    test/                 unit tests
  sample-data/sales.csv
  docker-compose.yml
```

## Limitations and next steps

- Only the first sheet of a workbook is read
- No user accounts yet; all datasets are visible to everyone using the instance
- Possible additions: JWT auth, multi-sheet selection, charts for any column pair, CSV/PDF export of the insights report, background jobs for very large files

## License

MIT
